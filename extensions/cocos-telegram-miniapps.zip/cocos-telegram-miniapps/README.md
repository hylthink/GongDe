# Cocos-Telegram-miniapps

Using Telegram Mini Apps extension in CocosCreator

## Install

```bash
# Install dependent modules
npm install
# build
npm run build
```
